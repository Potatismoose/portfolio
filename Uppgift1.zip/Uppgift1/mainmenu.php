<nav class="main-navigation">
  <div class="flexmain">
    <ul class="menu-list">
      <li class="menu-item"><a href="#about"><span class="menu-icon"><i class="fas fa-user-ninja"></i></span><span class="menu-text"> Om mig</span></a></li>
      <li class="menu-item"><a href="#portfolio"><span class="menu-icon"><i class="fas fa-briefcase"></i></span><span class="menu-text">Portfolio</span></a></li>
      <li class="menu-item"><a href="#cv"><span class="menu-icon"><i class="fas fa-align-left"></i></span><span class="menu-text"> Cv / skills</span></a></li>
      <li class="menu-item"><a href="#contact"><span class="menu-icon"><i class="fas fa-address-card"></i></span><span class="menu-text">Kontakt</span></a></li>        
    </ul>
    <h1 class="header-text" id="right">B.Christensen</h1>
  </div>
  </nav>